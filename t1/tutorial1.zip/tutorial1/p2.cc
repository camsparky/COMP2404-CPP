#include<iostream>

using namespace std;

int main(){
	int n1, n2;
	cout << "Please Enter Two Integers"<<endl;
	cin >> n1 ;
    cin >> n2;
	cout << "The product of " << n1 << " and "<<n2<<" is "<<n1*n2<<endl;
	return 0;
}

#ifndef DEFS_H
#define DEFS_H

#define MAX_PODS 5
#define MAX_EPS 100

#endif